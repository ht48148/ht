﻿<?php
?>
<?php
include("../includes/common.php");
?>
<!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=0" name="viewport">
<title>思狐支付 | 在线测试 </title>
    <meta name="keywords" content="思狐支付,码支付,易支付,思狐易支付,支付网,易支付,简支付,,第四方支付支付平台,自动支付平台,自动支付,思狐支付平台,易付,卡网,卡密售卖,自动售卡" />
    <meta name="description" content="思狐支付是一个专业的帮助开发者快速将支付（支付宝，钱包，微信）集成到自己相应产品，满5元每日结算无手续费，费率低，结算快，安全、稳定、快捷、正规，24小时不间断提供自动支付服务。" />
<link rel="shortcut icon" href="favicon.ico">
<link href="css/style.css" rel="stylesheet" type="text/css">
<script src="js/jquery-1.11.3.min.js"></script>
<script>
	var lastClickTime;
	var orderNo="20190501022148125";
	function isPhone() {  
	    var sUserAgent = navigator.userAgent.toLowerCase();  
	    var bIsIpad = sUserAgent.match(/ipad/i) == "ipad";  
	    var bIsIphoneOs = sUserAgent.match(/iphone os/i) == "iphone os";  
	    var bIsMidp = sUserAgent.match(/midp/i) == "midp";  
	    var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";  
	    var bIsUc = sUserAgent.match(/ucweb/i) == "ucweb";  
	    var bIsAndroid = sUserAgent.match(/android/i) == "android";  
	    var bIsCE = sUserAgent.match(/windows ce/i) == "windows ce";  
	    var bIsWM = sUserAgent.match(/windows mobile/i) == "windows mobile";
	    if (!(bIsIpad || bIsIphoneOs || bIsMidp || bIsUc7 || bIsUc || bIsAndroid || bIsCE || bIsWM) ){  
	        return false; 
	    } else {
	    	return true;
	    }  
	}
	if(isPhone()){

	}
	$(function(){
		$('.PayMethod12 ul li').each(function(index, element) {
            $('.PayMethod12 ul li').eq(5*index+4).css('margin-right','0')
        });
		
		//支付方式选择
		$('.PayMethod12 ul li').click(function(e) {
            //$(this).addClass('active').siblings().removeClass('active');
        });	
		
		$(".pay_li").click(function(){
			var v = $(this).attr("value");
			if(v == ""){
				alert("待开发");
				return false;
			}else{
				$(".pay_li").removeClass("active");
				$(this).addClass("active");
				$("#type").val(v);
			}
		});
		//点击立即支付按钮
		$(".immediate_pay").click(function(){
			//alert("公司业务调整，体验支付功能暂时下线！");return;
			
			//判断用户是否选择了支付渠道
			if(!$(".pay_li").hasClass("active")){
				message_show("请选择支付功能");
				return false;
			}
			//获取选择的支付渠道的li
			var payli =$(".pay_li[class='pay_li active']");
			if(payli[0]){
				$("#type").val($(payli[0]).attr("value"));
				$("#payFrom").submit();
			}else{
				message_show("请重新选择支付功能");
			}
			
		});
		
	
		$('.mt_agree').click(function(e) {
	        $('.mt_agree').fadeOut(300);
	    });
		
		$('.mt_agree_main').click(function(e) {
	        return false;
	    });	

		
		$('.pay_sure12-main').click(function(e) {
			return false;
		});
	});

	function hide(){
		$('.pay_sure12').fadeOut(300);
	}
</script>
</head>
<body style="background-color:#f7f7f7">

<!--导航-->
<div class="w100 navBD12">
    <div class="w1080 nav12">
        <div class="nav12-left">
            <a href="/"><img src="logo.png" alt="思狐支付" title="思狐支付" style="max-height: 50px;"></a>
            <span class="shouyintai"></span>
        </div>
            
        </div>

    </div>
</div>
<!--订单金额-->
<div class="w1080 order-amount12">
<form name=alipayment id="payFrom" action=epayapi.php method=post style="display: none;">
	<input name="WIDout_trade_no" value="20190501022148796"/>
	<input name="WIDsubject" value="Vip体验服务"  />
	<input name="WIDtotal_fee" value="1"  /> 
	<input name="type" id="type" value="alipay" />
</form>  
    <ul class="order-amount12-left">
        <li>
            <span>商品名称：</span>
            <span>Vip体验服务</span>
        </li>
        <li>
            <span>商户订单号：</span>
                      <span><?php echo date("YmdHis") . mt_rand(100, 999);?></span>
      </li>

        </li>
    </ul>
    <div class="order-amount12-right">
        <span>订单金额：</span>
        <strong>1.00</strong>
        <span>元</span>
    </div>	
</div>
<!--支付方式-->
<div class="w1080 PayMethod12">
    <div class="row">
        <h2>支付方式</h2>
        <ul>
					<li class="pay_li active" data_power_id="3000000011" data_product_id="3000000001" value="alipay">
						 <i class="i1"></i>
                		<span>支付宝</span>
					</li>
	 
					<li class="pay_li" data_power_id="3000000021" data_product_id="3000000001" value="wxpay">
						<i class="i2"></i>
                		<span>微信支付</span>
					</li>
					<li class="pay_li" data_power_id="3000000031" data_product_id="3000000001" value="qqpay">
						<i class="i3"></i>
                		<span>QQ钱包</span>
					</li>

        </ul>
    </div>
</div>
<!--立即支付-->
<div class="w1080 immediate-pay12" style="padding-top:1em;padding-bottom: 1em;padding-right: 1em;">
	<div class="immediate-pay12-right">
    	<span>需支付：<strong>1.00</strong>元</span>
        <a class="immediate_pay">立即支付</a>
    </div>
</div>
<div class="mt_agree">
	<div class="mt_agree_main">
		<h2>提示信息</h2>
		<p id="errorContent" style="text-align:center;line-height:36px;"></p>
		<a class="close_btn" onclick="message_hide()">确定</a>
	</div>
</div>
<!--底部-->
<div class="w1080 footer12">
    <p>All Rights Reserved. 2017-2019</p>
</div>



<script type="text/javascript">
	function message_show(message){
		$("#errorContent").html(message);
		$('.mt_agree').fadeIn(300);
	}
	
	function message_hide(){
		$('.mt_agree').fadeOut(300);
	}
	
</script>