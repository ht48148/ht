<?php
/**
 * 请到 http://connect.opensns.qq.com/申请appid, appkey, 并注册callback地址：http://你的域名/user/connect.php
 */
//申请到的appid
$QC_config["appid"]  = 101435815;

//申请到的appkey
$QC_config["appkey"] = "95d22dfd1b290aa69b0fc8dbcb1df1c9";

//callback url
$QC_config["callback"] = 'http://api.pay.52saf.com/user/connect.php';
?>